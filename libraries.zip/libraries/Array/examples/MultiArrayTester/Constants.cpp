#include "Constants.h"


namespace constants
{
const long baud = 115200;

const int x_default[] = {1,2,3};
const int y_default[] = {4,5,6,7};
const int z_default[] = {8,9,10,11,12};
}
