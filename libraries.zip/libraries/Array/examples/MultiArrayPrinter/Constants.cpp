#include "Constants.h"


namespace constants
{
const long baud = 115200;

const int x_default[] = {10};
const int y_default[] = {11,12};
const int z_default[] = {13,14,15};
}
